interface Livro {
    titulo: string;
    autor: string;
    anoPublicacao: number;
}

function exibirInformacoes(livro: Livro): string {
    return `O livro "${livro.titulo}" foi escrito por ${livro.autor} e publicado em ${livro.anoPublicacao}.`;
}

const livro1: Livro = {
    titulo: "1984",
    autor: "George Orwell",
    anoPublicacao: 1949
};

console.log(exibirInformacoes(livro1));
