let cidade: string = "São Paulo";
let temperatura: number = 25.5;
let chovendo: boolean = false;

console.log(`Cidade: ${cidade}`);
console.log(`Temperatura: ${temperatura}`);
console.log(`Chovendo: ${chovendo}`);
