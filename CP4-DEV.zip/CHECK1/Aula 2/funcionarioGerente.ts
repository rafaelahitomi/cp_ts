// funcionarioGerente.ts
class Funcionario {
    nome: string;
    cargo: string;
    salario: number;

    constructor(nome: string, cargo: string, salario: number) {
        this.nome = nome;
        this.cargo = cargo;
        this.salario = salario;
    }

    descricao(): string {
        return `Nome: ${this.nome}, Cargo: ${this.cargo}, Salário: R$${this.salario}`;
    }
}

class Gerente extends Funcionario {
    departamento: string;

    constructor(nome: string, cargo: string, salario: number, departamento: string) {
        super(nome, cargo, salario);
        this.departamento = departamento;
    }

    descricaoCompleta(): string {
        return `${this.descricao()}, Departamento: ${this.departamento}`;
    }
}

const gerenteExemplo = new Gerente("Carlos", "Gerente de TI", 12000, "Tecnologia");
console.log(gerenteExemplo.descricaoCompleta());
