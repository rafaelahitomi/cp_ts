// financeiro.ts
namespace Financeiro {
    export function calcularImposto(valor: number, taxa: number): number {
        return valor * (taxa / 100);
    }

    export function calcularDesconto(valor: number, desconto: number): number {
        return valor - (valor * (desconto / 100));
    }

    export class Orcamento {
        valorTotal: number;
        itens: string[];

        constructor(valorTotal: number, itens: string[]) {
            this.valorTotal = valorTotal;
            this.itens = itens;
        }

        aplicarDesconto(desconto: number): void {
            this.valorTotal = calcularDesconto(this.valorTotal, desconto);
        }

        aplicarImposto(taxa: number): void {
            this.valorTotal += calcularImposto(this.valorTotal, taxa);
        }
    }
}
