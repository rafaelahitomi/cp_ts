// produtoPagamento.ts
interface Produto {
    nome: string;
    preco: number;
    categoria: string;
}

type FormaPagamento = 'dinheiro' | 'cartão' | 'pix';

function descricaoProduto(produto: Produto, pagamento: FormaPagamento): string {
    return `O produto ${produto.nome}, da categoria ${produto.categoria}, custa R$${produto.preco} e será pago com ${pagamento}.`;
}

const produtoExemplo: Produto = {
    nome: "Notebook",
    preco: 2500,
    categoria: "Eletrônicos"
};

console.log(descricaoProduto(produtoExemplo, 'cartão'));
