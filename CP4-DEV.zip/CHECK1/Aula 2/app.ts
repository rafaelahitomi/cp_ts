// app.ts
/// <reference path="financeiro.ts" />

const orcamento = new Financeiro.Orcamento(1000, ["Item 1", "Item 2"]);

console.log(`Valor Total Inicial: R$${orcamento.valorTotal}`);

orcamento.aplicarDesconto(10);
console.log(`Valor após Desconto: R$${orcamento.valorTotal}`);

orcamento.aplicarImposto(5);
console.log(`Valor após Imposto: R$${orcamento.valorTotal}`);
