// pessoaEmpregado.ts
type Pessoa = {
    nome: string;
    idade: number;
};

type Empregado = {
    empresa: string;
    salario: number;
};

type PessoaEmpregado = Pessoa & Empregado;

function descricaoPessoaEmpregado(pessoaEmpregado: PessoaEmpregado): string {
    return `Nome: ${pessoaEmpregado.nome}, Idade: ${pessoaEmpregado.idade}, Empresa: ${pessoaEmpregado.empresa}, Salário: R$${pessoaEmpregado.salario}`;
}

const pessoaEmpregadoExemplo: PessoaEmpregado = {
    nome: "Ana",
    idade: 28,
    empresa: "TechCorp",
    salario: 6000
};

console.log(descricaoPessoaEmpregado(pessoaEmpregadoExemplo));
