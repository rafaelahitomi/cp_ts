// Pedido.ts
import { Cliente } from "./Cliente";

export class Pedido {
    cliente: Cliente;
    produto: string;
    valor: number;

    constructor(cliente: Cliente, produto: string, valor: number) {
        this.cliente = cliente;
        this.produto = produto;
        this.valor = valor;
    }

    exibirDetalhes(): string {
        return `Cliente: ${this.cliente.nome}, Produto: ${this.produto}, Valor: R$${this.valor}`;
    }
}

const clienteExemplo = new Cliente("Pedro", "pedro@example.com");
const pedidoExemplo = new Pedido(clienteExemplo, "Smartphone", 1500);

console.log(pedidoExemplo.exibirDetalhes());
